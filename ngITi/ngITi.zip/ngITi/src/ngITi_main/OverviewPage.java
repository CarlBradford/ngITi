/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ngITi_main;

import java.awt.Color;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;

public class OverviewPage extends javax.swing.JInternalFrame {

    /**
     * Creates new form OverviewPage
     */
     Color panDefault, panEnter, panClick;
     
    public OverviewPage() {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI iu = (BasicInternalFrameUI)this.getUI();
        iu.setNorthPane(null);
        
        panDefault = new Color(5,45,77);
        panClick = new Color(99, 136, 179);
        panEnter = new Color(101, 154, 216);

         //total patients all time
       try {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
        PreparedStatement pst = con.prepareStatement("SELECT COUNT(*) AS total_patients FROM patients");
        ResultSet rs = pst.executeQuery();
    
        if (rs.next()) {
        int totalPatients = rs.getInt("total_patients");
        tpatall.setText(String.valueOf(totalPatients));
        } else {
        JOptionPane.showMessageDialog(null, "No Patients Found");
        }

        } catch (HeadlessException | ClassNotFoundException | SQLException e) {
        JOptionPane.showMessageDialog(this, e.getMessage());
        }
       
       //total patient this month
   try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
    String sql = "SELECT COUNT(*) AS total_patientsTM FROM patients WHERE MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())";
    PreparedStatement pst = con.prepareStatement(sql);

    ResultSet rs = pst.executeQuery();

    if (rs.next()) {
        int totalPatientsTM = rs.getInt("total_patientsTM");
        tpat.setText(String.valueOf(totalPatientsTM));
    } else {
        JOptionPane.showMessageDialog(null, "No Patients Found");
    }

} catch (HeadlessException | ClassNotFoundException | SQLException e) {
    JOptionPane.showMessageDialog(this, e.getMessage());
}


        //todays appointments
        try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
    PreparedStatement pst = con.prepareStatement("SELECT COUNT(*) AS today_appointments FROM appointments WHERE DATE(date) = CURRENT_DATE");
    ResultSet rs = pst.executeQuery();

    if (rs.next()) {
        int totalAppointments = rs.getInt("today_appointments");
        tapp.setText(String.valueOf(totalAppointments));
    } else {
        JOptionPane.showMessageDialog(null, "No Appointments Found for Today");
    }

} catch (HeadlessException | ClassNotFoundException | SQLException e) {
    JOptionPane.showMessageDialog(this, e.getMessage());
}

        //total appointments all time
        try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
    PreparedStatement pst = con.prepareStatement("SELECT COUNT(*) AS total_appointments FROM appointments");
    ResultSet rs = pst.executeQuery();

    if (rs.next()) {
        int totalAppointments = rs.getInt("total_appointments");
        tappall.setText(String.valueOf(totalAppointments));
    } else {
        JOptionPane.showMessageDialog(null, "No Appointments Found");
    }

} catch (HeadlessException | ClassNotFoundException | SQLException e) {
    JOptionPane.showMessageDialog(this, e.getMessage());
}
        
        //booking table
         try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull","root","");
            Statement st = con.createStatement();
            ResultSet res = st.executeQuery("select * from bookings");
            res.last();
            int row = res.getRow();
            int col = res.getMetaData().getColumnCount();
            res.beforeFirst();
            String rowData[][] = new String[row][col];
            int r = 0;
            while(res.next()){
                for(int i = 0;i<col;i++){
                    rowData[r][i]=res.getString(i+1);
                }
                r++;
            }
            String[] columnName = {"Booking ID", "Full Name", "Date", "Contact Number"};
            DefaultTableModel model = (DefaultTableModel) booktable.getModel();
            model.setDataVector(rowData,columnName);

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }

    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDesktopPanel = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tapp = new javax.swing.JLabel();
        tappall = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        tpat = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tpatall = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        booktable = new table.Table();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        txtbook = new javax.swing.JTextField();
        jPanRefresh = new javax.swing.JPanel();
        loginlbl2 = new javax.swing.JLabel();
        jPanDone = new javax.swing.JPanel();
        loginlbl = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(1490, 1080));
        setMinimumSize(new java.awt.Dimension(1490, 1080));

        jDesktopPanel.setBackground(new java.awt.Color(242, 245, 250));
        jDesktopPanel.setMaximumSize(new java.awt.Dimension(1490, 1080));
        jDesktopPanel.setMinimumSize(new java.awt.Dimension(1490, 1080));
        jDesktopPanel.setPreferredSize(new java.awt.Dimension(1490, 1080));
        jDesktopPanel.setLayout(null);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setOpaque(false);
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel17.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(27, 25, 91));
        jLabel17.setText("TODAY'S APPOINTMENT");
        jPanel3.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 16, -1, -1));

        jLabel21.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(27, 25, 91));
        jLabel21.setText("TOTAL APPOINTMENTS ALL TIME");
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 210, -1, -1));

        jLabel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(242, 245, 250), 4));
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 173, 370, -1));

        tapp.setBackground(new java.awt.Color(255, 255, 255));
        tapp.setFont(new java.awt.Font("Century Gothic", 1, 60)); // NOI18N
        tapp.setForeground(new java.awt.Color(27, 25, 91));
        tapp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(tapp, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 122, 101));

        tappall.setBackground(new java.awt.Color(255, 255, 255));
        tappall.setFont(new java.awt.Font("Century Gothic", 1, 60)); // NOI18N
        tappall.setForeground(new java.awt.Color(27, 25, 91));
        tappall.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(tappall, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 125, 101));

        jLabel16.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(5, 45, 77));
        jLabel16.setText("appointments");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, -1, -1));

        jLabel22.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(5, 45, 77));
        jLabel22.setText("appointments");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 290, -1, -1));

        jDesktopPanel.add(jPanel3);
        jPanel3.setBounds(470, 540, 400, 360);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setOpaque(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tpat.setBackground(new java.awt.Color(255, 255, 255));
        tpat.setFont(new java.awt.Font("Century Gothic", 1, 60)); // NOI18N
        tpat.setForeground(new java.awt.Color(27, 25, 91));
        tpat.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(tpat, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 54, 131, 101));

        jLabel18.setBackground(new java.awt.Color(255, 255, 255));
        jLabel18.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(27, 25, 91));
        jLabel18.setText("TOTAL PATIENT THIS MONTH");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 14, -1, -1));

        jLabel20.setBackground(new java.awt.Color(255, 255, 255));
        jLabel20.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(27, 25, 91));
        jLabel20.setText("TOTAL PATIENT ALL TIME");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, -1));

        jLabel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(242, 245, 250), 4));
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 173, 370, -1));

        tpatall.setBackground(new java.awt.Color(255, 255, 255));
        tpatall.setFont(new java.awt.Font("Century Gothic", 1, 60)); // NOI18N
        tpatall.setForeground(new java.awt.Color(27, 25, 91));
        tpatall.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(tpatall, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 128, 101));

        jLabel8.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(5, 45, 77));
        jLabel8.setText("patients");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, -1, -1));

        jLabel10.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(5, 45, 77));
        jLabel10.setText("patients");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 290, -1, -1));

        jDesktopPanel.add(jPanel1);
        jPanel1.setBounds(40, 540, 400, 370);

        booktable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Booking ID", "Full Name", "Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(booktable);

        jDesktopPanel.add(jScrollPane1);
        jScrollPane1.setBounds(950, 310, 478, 610);

        jLabel9.setBackground(new java.awt.Color(242, 245, 250));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dbbigicon.png"))); // NOI18N
        jDesktopPanel.add(jLabel9);
        jLabel9.setBounds(40, 90, 50, 50);

        jLabel11.setFont(new java.awt.Font("Century Gothic", 1, 50)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(5, 45, 77));
        jLabel11.setText("Good Day!");
        jDesktopPanel.add(jLabel11);
        jLabel11.setBounds(40, 160, 264, 62);

        jLabel12.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(5, 45, 77));
        jLabel12.setText("Dashboard Overview");
        jDesktopPanel.add(jLabel12);
        jLabel12.setBounds(110, 90, 370, 45);

        jLabel13.setBackground(new java.awt.Color(242, 245, 250));
        jLabel13.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/clinicinfo.png"))); // NOI18N
        jDesktopPanel.add(jLabel13);
        jLabel13.setBounds(40, 230, 840, 249);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/boxsmall.png"))); // NOI18N
        jDesktopPanel.add(jLabel14);
        jLabel14.setBounds(470, 510, 400, 426);

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/boxsmall.png"))); // NOI18N
        jDesktopPanel.add(jLabel15);
        jLabel15.setBounds(40, 510, 400, 426);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/admin no pic.png"))); // NOI18N
        jDesktopPanel.add(jLabel1);
        jLabel1.setBounds(1280, 20, 138, 140);

        jLabel2.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(5, 45, 77));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("admin");
        jDesktopPanel.add(jLabel2);
        jLabel2.setBounds(1140, 100, 140, 20);

        jLabel3.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(5, 45, 77));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Ethan Lee");
        jDesktopPanel.add(jLabel3);
        jLabel3.setBounds(1140, 80, 140, 20);

        jLabel23.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel23.setText("Booking ID:");
        jDesktopPanel.add(jLabel23);
        jLabel23.setBounds(1050, 270, 110, 23);

        txtbook.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        txtbook.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtbook.setToolTipText("");
        txtbook.setBorder(null);
        txtbook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbookActionPerformed(evt);
            }
        });
        jDesktopPanel.add(txtbook);
        txtbook.setBounds(1170, 270, 140, 31);

        jPanRefresh.setBackground(new java.awt.Color(5, 45, 77));
        jPanRefresh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanRefreshMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanRefreshMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanRefreshMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanRefreshMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jPanRefreshMouseReleased(evt);
            }
        });

        loginlbl2.setFont(new java.awt.Font("Century Gothic", 1, 28)); // NOI18N
        loginlbl2.setForeground(new java.awt.Color(255, 255, 255));
        loginlbl2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loginlbl2.setText("REFRESH");

        javax.swing.GroupLayout jPanRefreshLayout = new javax.swing.GroupLayout(jPanRefresh);
        jPanRefresh.setLayout(jPanRefreshLayout);
        jPanRefreshLayout.setHorizontalGroup(
            jPanRefreshLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanRefreshLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(loginlbl2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );
        jPanRefreshLayout.setVerticalGroup(
            jPanRefreshLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanRefreshLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(loginlbl2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jDesktopPanel.add(jPanRefresh);
        jPanRefresh.setBounds(1200, 200, 220, 50);

        jPanDone.setBackground(new java.awt.Color(5, 45, 77));
        jPanDone.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanDoneMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanDoneMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanDoneMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanDoneMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jPanDoneMouseReleased(evt);
            }
        });

        loginlbl.setFont(new java.awt.Font("Century Gothic", 1, 28)); // NOI18N
        loginlbl.setForeground(new java.awt.Color(255, 255, 255));
        loginlbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loginlbl.setText("DONE");

        javax.swing.GroupLayout jPanDoneLayout = new javax.swing.GroupLayout(jPanDone);
        jPanDone.setLayout(jPanDoneLayout);
        jPanDoneLayout.setHorizontalGroup(
            jPanDoneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanDoneLayout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(loginlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );
        jPanDoneLayout.setVerticalGroup(
            jPanDoneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanDoneLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(loginlbl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jDesktopPanel.add(jPanDone);
        jPanDone.setBounds(950, 200, 220, 50);

        jPanel2.setLayout(null);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ngITibgg.png"))); // NOI18N
        jPanel2.add(jLabel4);
        jLabel4.setBounds(0, 0, 1490, 1080);

        jDesktopPanel.add(jPanel2);
        jPanel2.setBounds(0, 0, 1530, 1130);

        jLabel5.setText("jLabel5");
        jDesktopPanel.add(jLabel5);
        jLabel5.setBounds(600, 640, 51, 20);

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/boxsmall.png"))); // NOI18N
        jDesktopPanel.add(jLabel19);
        jLabel19.setBounds(470, 510, 400, 426);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jDesktopPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1132, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jPanDoneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanDoneMouseClicked
        //delete the appointment
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
            PreparedStatement pst = con.prepareStatement("DELETE FROM bookings where bookingid = ?");
            DefaultTableModel model = (DefaultTableModel)booktable.getModel();
            pst.setString(1,txtbook.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this,"Done");
            

        }catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_jPanDoneMouseClicked

    private void jPanDoneMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanDoneMouseEntered
        jPanDone.setBackground(panEnter);
    }//GEN-LAST:event_jPanDoneMouseEntered

    private void jPanDoneMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanDoneMouseExited
        jPanDone.setBackground(panDefault);
    }//GEN-LAST:event_jPanDoneMouseExited

    private void jPanDoneMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanDoneMousePressed
        jPanDone.setBackground(panClick);
    }//GEN-LAST:event_jPanDoneMousePressed

    private void jPanDoneMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanDoneMouseReleased
        jPanDone.setBackground(panDefault);
    }//GEN-LAST:event_jPanDoneMouseReleased

    private void jPanRefreshMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanRefreshMouseClicked
        //display the latest table
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull","root","");
            Statement st = con.createStatement();
            ResultSet res = st.executeQuery("select * from bookings");
            res.last();
            int row = res.getRow();
            int col = res.getMetaData().getColumnCount();
            res.beforeFirst();
            String rowData[][] = new String[row][col];
            int r = 0;
            while(res.next()){
                for(int i = 0;i<col;i++){
                    rowData[r][i]=res.getString(i+1);
                }
                r++;
            }
            String[] columnName = {"Booking ID", "Full Name", "Date", "Contact Number"};
            DefaultTableModel model = (DefaultTableModel) booktable.getModel();
            model.setDataVector(rowData,columnName);

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_jPanRefreshMouseClicked

    private void jPanRefreshMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanRefreshMouseEntered
        jPanRefresh.setBackground(panEnter);
    }//GEN-LAST:event_jPanRefreshMouseEntered

    private void jPanRefreshMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanRefreshMouseExited
        jPanRefresh.setBackground(panDefault);
    }//GEN-LAST:event_jPanRefreshMouseExited

    private void jPanRefreshMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanRefreshMousePressed
       jPanRefresh.setBackground(panClick);
    }//GEN-LAST:event_jPanRefreshMousePressed

    private void jPanRefreshMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanRefreshMouseReleased
       jPanRefresh.setBackground(panDefault);
    }//GEN-LAST:event_jPanRefreshMouseReleased

    private void txtbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbookActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtbookActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private table.Table booktable;
    private javax.swing.JPanel jDesktopPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanDone;
    private javax.swing.JPanel jPanRefresh;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel loginlbl;
    private javax.swing.JLabel loginlbl2;
    private javax.swing.JLabel tapp;
    private javax.swing.JLabel tappall;
    private javax.swing.JLabel tpat;
    private javax.swing.JLabel tpatall;
    private javax.swing.JTextField txtbook;
    // End of variables declaration//GEN-END:variables

}
