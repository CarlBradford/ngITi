
package ngITi_main;

public class NGITI_appmain {

  
    public static void main(String[] args) {
        
    }
    
}
