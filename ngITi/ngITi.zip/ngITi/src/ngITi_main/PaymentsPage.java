/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ngITi_main;

import java.awt.Color;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author carld
 */
public class PaymentsPage extends javax.swing.JInternalFrame {

    /**
     * Creates new form PaymentsTab
     */
    public PaymentsPage() throws ClassNotFoundException, SQLException {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI iu = (BasicInternalFrameUI)this.getUI();
        iu.setNorthPane(null);
        
        
       //this month income
   try {
    Class.forName("com.mysql.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "")) {
                PreparedStatement pst = con.prepareStatement("SELECT COALESCE(SUM(price), 0) AS total_price FROM payments WHERE MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())");
                ResultSet rs = pst.executeQuery();
                
                if (rs.next()) {
                    double totalPriceThisMonth = rs.getDouble("total_price");
                    String formattedTotalPrice = String.format("%.2f", totalPriceThisMonth);
                    tmonth.setText(formattedTotalPrice);
                } else {
                    JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
                }       }

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}

       
       //previous month income
       try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
     PreparedStatement pst = con.prepareStatement("SELECT SUM(price) AS total_price FROM payments WHERE MONTH(date) = MONTH(CURRENT_DATE) - 1 AND YEAR(date) = YEAR(CURRENT_DATE) - (CASE WHEN MONTH(CURRENT_DATE) = 1 THEN 1 ELSE 0 END)");
     ResultSet rs = pst.executeQuery()) {

    if (rs.next()) {
        double totalPricePrevMonth = rs.getDouble("total_price");
        String formattedTotalPricePrev = String.format("%.2f", totalPricePrevMonth);
        pmonth.setText(formattedTotalPricePrev);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}

        
         //total income 
        try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");    
    PreparedStatement pst = con.prepareStatement("SELECT SUM(price) AS total_price FROM payments");
    ResultSet rs = pst.executeQuery();
    
    if (rs.next()) {
        double totalIncome = rs.getDouble("total_price");
        String formattedTotal = String.format("%.2f", totalIncome);
        totalincome.setText(formattedTotal);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
        //display table
         try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull","root","");
            Statement st = con.createStatement();
            ResultSet res = st.executeQuery("select * from payments");
            res.last();
            int row = res.getRow();
            int col = res.getMetaData().getColumnCount();
            res.beforeFirst();
            String rowData[][] = new String[row][col];
            int r = 0;
            while(res.next()){
                for(int i = 0;i<col;i++){
                    rowData[r][i]=res.getString(i+1);
                }
                r++;
            }
            String[] columnName = {"Payment ID","Appointment ID","Patient ID","Service ID","Date", "Price"};
            DefaultTableModel model = (DefaultTableModel)paytable.getModel();
            model.setDataVector(rowData,columnName);

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
      

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        payid = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        appid = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        patid = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane1 = new scrollpane.ScrollPaneWin11();
        paytable = new table.Table();
        jbtnupl = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        pmonth = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        totalincome = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        tmonth = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        price = new javax.swing.JTextField();
        showpat = new javax.swing.JLabel();
        showapt = new javax.swing.JLabel();
        showser = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        datep = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        service = new ngITi_main.Combobox();
        jLabel4 = new javax.swing.JLabel();
        search = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();

        jPanel2.setBackground(new java.awt.Color(242, 245, 250));
        jPanel2.setMaximumSize(new java.awt.Dimension(1490, 1080));
        jPanel2.setMinimumSize(new java.awt.Dimension(1490, 1080));
        jPanel2.setOpaque(false);

        jLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(218, 218, 223), 2));

        jPanel3.setMaximumSize(new java.awt.Dimension(1490, 970));
        jPanel3.setMinimumSize(new java.awt.Dimension(1490, 970));
        jPanel3.setOpaque(false);
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Century Gothic", 1, 26)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(5, 45, 77));
        jLabel3.setText("Payment ID:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 16, -1, -1));

        payid.setFont(new java.awt.Font("Century Gothic", 0, 22)); // NOI18N
        payid.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(218, 218, 223), 1, true));
        payid.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        payid.setVerifyInputWhenFocusTarget(false);
        payid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payidActionPerformed(evt);
            }
        });
        jPanel3.add(payid, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 52, 309, 44));

        jLabel5.setFont(new java.awt.Font("Century Gothic", 1, 26)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(5, 45, 77));
        jLabel5.setText("Patient ID:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 122, -1, -1));

        jLabel6.setFont(new java.awt.Font("Century Gothic", 1, 26)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(5, 45, 77));
        jLabel6.setText("Appointment ID:");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(436, 16, -1, -1));

        appid.setFont(new java.awt.Font("Century Gothic", 0, 22)); // NOI18N
        appid.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(218, 218, 223), 1, true));
        appid.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        appid.setVerifyInputWhenFocusTarget(false);
        appid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                appidActionPerformed(evt);
            }
        });
        jPanel3.add(appid, new org.netbeans.lib.awtextra.AbsoluteConstraints(436, 52, 309, 44));

        jLabel7.setFont(new java.awt.Font("Century Gothic", 1, 26)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(5, 45, 77));
        jLabel7.setText("Service ID:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(436, 122, -1, -1));

        patid.setFont(new java.awt.Font("Century Gothic", 0, 22)); // NOI18N
        patid.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(218, 218, 223), 1, true));
        patid.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        patid.setVerifyInputWhenFocusTarget(false);
        patid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                patidActionPerformed(evt);
            }
        });
        jPanel3.add(patid, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 164, 309, 44));

        jLabel33.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(218, 218, 223), 2));
        jPanel3.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 296, 1489, -1));

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));
        jPanel16.setOpaque(false);
        jPanel16.setPreferredSize(new java.awt.Dimension(1490, 593));

        jLabel12.setFont(new java.awt.Font("Century Gothic", 1, 26)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(5, 45, 77));
        jLabel12.setText("Payment History");

        paytable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Payment ID", "Appointment ID", "Patient ID", "Services ID", "Date", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        paytable.setOpaque(false);
        paytable.setRequestFocusEnabled(false);
        paytable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                paytableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(paytable);

        jbtnupl.setBackground(new java.awt.Color(5, 45, 77));
        jbtnupl.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jbtnupl.setForeground(new java.awt.Color(255, 255, 255));
        jbtnupl.setText("Refresh List");
        jbtnupl.setToolTipText("");
        jbtnupl.setBorder(null);
        jbtnupl.setBorderPainted(false);
        jbtnupl.setOpaque(false);
        jbtnupl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnuplActionPerformed(evt);
            }
        });

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/payip.png"))); // NOI18N

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(jLabel17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jbtnupl, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addGap(0, 32, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel12)
                        .addComponent(jbtnupl, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(96, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 309, 1054, -1));

        jPanel7.setOpaque(false);

        pmonth.setFont(new java.awt.Font("Century Gothic", 1, 50)); // NOI18N
        pmonth.setForeground(new java.awt.Color(5, 45, 77));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/phsign.png"))); // NOI18N

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pmonth, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(pmonth, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 530, -1, -1));

        jPanel9.setOpaque(false);

        totalincome.setFont(new java.awt.Font("Century Gothic", 1, 50)); // NOI18N
        totalincome.setForeground(new java.awt.Color(5, 45, 77));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/phsign.png"))); // NOI18N

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(totalincome, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(totalincome, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 720, -1, -1));

        jPanel6.setOpaque(false);

        tmonth.setFont(new java.awt.Font("Century Gothic", 1, 50)); // NOI18N
        tmonth.setForeground(new java.awt.Color(5, 45, 77));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/phsign.png"))); // NOI18N

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tmonth, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(tmonth, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 390, 330, -1));

        jPanel4.setOpaque(false);

        jButton1.setBackground(new java.awt.Color(5, 45, 77));
        jButton1.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/add icon.png"))); // NOI18N
        jButton1.setText("  Add Payment");
        jButton1.setBorder(null);
        jButton1.setBorderPainted(false);
        jButton1.setOpaque(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(5, 45, 77));
        jButton2.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/update icon.png"))); // NOI18N
        jButton2.setText("   Update");
        jButton2.setBorder(null);
        jButton2.setBorderPainted(false);
        jButton2.setOpaque(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(5, 45, 77));
        jButton3.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/del icon.png"))); // NOI18N
        jButton3.setText("    Delete");
        jButton3.setBorder(null);
        jButton3.setBorderPainted(false);
        jButton3.setOpaque(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1165, 0, 270, -1));

        jLabel8.setFont(new java.awt.Font("Century Gothic", 1, 26)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(5, 45, 77));
        jLabel8.setText("Price:");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 120, -1, -1));

        price.setFont(new java.awt.Font("Century Gothic", 0, 22)); // NOI18N
        price.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(218, 218, 223), 1, true));
        price.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        price.setVerifyInputWhenFocusTarget(false);
        price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                priceActionPerformed(evt);
            }
        });
        jPanel3.add(price, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 160, 309, 44));

        showpat.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        showpat.setText("show Patients");
        showpat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showpatMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                showpatMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                showpatMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                showpatMousePressed(evt);
            }
        });
        jPanel3.add(showpat, new org.netbeans.lib.awtextra.AbsoluteConstraints(179, 132, -1, -1));

        showapt.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        showapt.setText("show");
        showapt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showaptMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                showaptMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                showaptMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                showaptMousePressed(evt);
            }
        });
        jPanel3.add(showapt, new org.netbeans.lib.awtextra.AbsoluteConstraints(649, 26, -1, -1));

        showser.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        showser.setText("show Services");
        showser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showserMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                showserMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                showserMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                showserMousePressed(evt);
            }
        });
        jPanel3.add(showser, new org.netbeans.lib.awtextra.AbsoluteConstraints(578, 132, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/incomeoverview.png"))); // NOI18N
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 316, -1, -1));

        datep.setFont(new java.awt.Font("Century Gothic", 0, 22)); // NOI18N
        datep.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(218, 218, 223), 1, true));
        datep.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        datep.setVerifyInputWhenFocusTarget(false);
        datep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                datepActionPerformed(evt);
            }
        });
        jPanel3.add(datep, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 60, 309, 44));

        jLabel15.setFont(new java.awt.Font("Century Gothic", 1, 26)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(5, 45, 77));
        jLabel15.setText("Date of Payment:");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 20, -1, -1));

        service.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "S001", "S002", "S003", "S004", "S005", "S006", "S007", "S008", "S009", "S010", "S011", "S012", "S013", "S014", "S015", "S016", "S017", "S018", "S019", "S020", "S021", "S022", " " }));
        service.setFont(new java.awt.Font("Century Gothic", 0, 22)); // NOI18N
        service.setLabeText("");
        jPanel3.add(service, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 160, 300, 50));

        jLabel4.setFont(new java.awt.Font("Century Gothic", 1, 22)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(5, 45, 77));
        jLabel4.setText("Search Payment");

        search.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        search.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(218, 218, 223), 1, true));
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchKeyReleased(evt);
            }
        });

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/payip.png"))); // NOI18N

        jLabel34.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(5, 45, 77));
        jLabel34.setText("Payments");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel14)
                        .addGap(9, 9, 9)
                        .addComponent(jLabel34)
                        .addGap(561, 561, 561)
                        .addComponent(jLabel4)
                        .addGap(17, 17, 17)
                        .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1490, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel14))
                    .addComponent(jLabel34)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel4))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(16, 16, 16)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 890, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ngITibgg.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel16)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel16)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1489, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void payidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_payidActionPerformed

    private void appidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_appidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_appidActionPerformed

    private void patidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_patidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_patidActionPerformed

    private void paytableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paytableMouseClicked
        //get values from table
        int SelectedRow =paytable.getSelectedRow();
        DefaultTableModel table=(DefaultTableModel)paytable.getModel();
        payid.setText(table.getValueAt(SelectedRow, 0).toString());
        appid.setText(table.getValueAt(SelectedRow, 1).toString());
        patid.setText(table.getValueAt(SelectedRow, 2).toString());
        service.setSelectedItem(table.getValueAt(SelectedRow, 3).toString());
        datep.setText(table.getValueAt(SelectedRow,4).toString());
        price.setText(table.getValueAt(SelectedRow, 5).toString());

    }//GEN-LAST:event_paytableMouseClicked

    private void jbtnuplActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnuplActionPerformed
        //update table
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull","root","");
            Statement st = con.createStatement();
            ResultSet res = st.executeQuery("select * from payments");
            res.last();
            int row = res.getRow();
            int col = res.getMetaData().getColumnCount();
            res.beforeFirst();
            String rowData[][] = new String[row][col];
            int r = 0;
            while(res.next()){
                for(int i = 0;i<col;i++){
                    rowData[r][i]=res.getString(i+1);
                }
                r++;
            }
            String[] columnName = {"Payment ID","Appointment ID","Patient ID","Service ID","Date", "Price"};
            DefaultTableModel model = (DefaultTableModel)paytable.getModel();
            model.setDataVector(rowData,columnName);

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_jbtnuplActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //add payments
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
            String sql = "INSERT INTO payments (PaymentID, AppointmentID, PatientID, ServiceID,Date, Price) VALUES (?, ?, ?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = con.prepareStatement(sql)) {
                preparedStatement.setString(1, payid.getText());
                preparedStatement.setString(2, appid.getText());
                preparedStatement.setString(3, patid.getText());
                 preparedStatement.setString(4, service.getSelectedItem() != null ? service.getSelectedItem().toString() : null);
                java.util.Date utilDate = new SimpleDateFormat("yyyy-MM-dd").parse(datep.getText());
                Date sqlDate = new Date(utilDate.getTime());
                preparedStatement.setDate(5, sqlDate);    
                double priceValue = Double.parseDouble(price.getText());
                preparedStatement.setDouble(6, priceValue);

                
                boolean b = preparedStatement.execute();

                if(!b){
                    JOptionPane.showMessageDialog(this, "Payment Added Successfully");
                    payid.setText(null);
                    appid.setText(null);
                    patid.setText(null);
                    service.setSelectedItem(null);
                    datep.setText(null);
                    price.setText(null);
                }
                else{
                    JOptionPane.showMessageDialog(this, "Error! Try Again");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "SQL Error: " + e.getMessage());
            } catch (ParseException ex) {
                Logger.getLogger(PaymentsPage.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (HeadlessException | ClassNotFoundException | NumberFormatException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
        
         //this month income
       try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");   
    PreparedStatement pst = con.prepareStatement("SELECT COALESCE(SUM(price), 0) AS total_price FROM payments WHERE MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())");
    ResultSet rs = pst.executeQuery();
    
    if (rs.next()) {
        double totalPriceThisMonth = rs.getDouble("total_price");
        String formattedTotalPrice = String.format("%.2f", totalPriceThisMonth);
        tmonth.setText(formattedTotalPrice);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

    con.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
       //previous month income
       try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
     PreparedStatement pst = con.prepareStatement("SELECT SUM(price) AS total_price FROM payments WHERE MONTH(date) = MONTH(CURRENT_DATE) - 1 AND YEAR(date) = YEAR(CURRENT_DATE) - (CASE WHEN MONTH(CURRENT_DATE) = 1 THEN 1 ELSE 0 END)");
     ResultSet rs = pst.executeQuery()) {

    if (rs.next()) {
        double totalPricePrevMonth = rs.getDouble("total_price");
        String formattedTotalPricePrev = String.format("%.2f", totalPricePrevMonth);
        pmonth.setText(formattedTotalPricePrev);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
       
        
         //total income 
        try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");    
    PreparedStatement pst = con.prepareStatement("SELECT SUM(price) AS total_price FROM payments");
    ResultSet rs = pst.executeQuery();
    
    if (rs.next()) {
        double totalIncome = rs.getDouble("total_price");
        String formattedTotal = String.format("%.2f", totalIncome);
        totalincome.setText(formattedTotal);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        //update payments
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
            PreparedStatement pst = con.prepareStatement("UPDATE payments SET appointmentid=?,patientid=?,serviceid=?,date=?, price=? where paymentid = ?");
            DefaultTableModel model = (DefaultTableModel)paytable.getModel();
            pst.setString(6,payid.getText());
            pst.setString(1,appid.getText());
            pst.setString(2,patid.getText());
            pst.setString(3, service.getSelectedItem() != null ? service.getSelectedItem().toString() : null);
            pst.setString(4,datep.getText());
            pst.setString(5,price.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this,"Record Updated Sucessfully");
            payid.setText(null);
            appid.setText(null);
            patid.setText(null);
            service.setSelectedItem(null);
            datep.setText(null);
            price.setText(null);

        }catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        
         //this month income
       try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");   
    PreparedStatement pst = con.prepareStatement("SELECT COALESCE(SUM(price), 0) AS total_price FROM payments WHERE MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())");
    ResultSet rs = pst.executeQuery();
    
    if (rs.next()) {
        double totalPriceThisMonth = rs.getDouble("total_price");
        String formattedTotalPrice = String.format("%.2f", totalPriceThisMonth);
        tmonth.setText(formattedTotalPrice);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

    con.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
       
       //previous month income
       try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
     PreparedStatement pst = con.prepareStatement("SELECT SUM(price) AS total_price FROM payments WHERE MONTH(date) = MONTH(CURRENT_DATE) - 1 AND YEAR(date) = YEAR(CURRENT_DATE) - (CASE WHEN MONTH(CURRENT_DATE) = 1 THEN 1 ELSE 0 END)");
     ResultSet rs = pst.executeQuery()) {

    if (rs.next()) {
        double totalPricePrevMonth = rs.getDouble("total_price");
        String formattedTotalPricePrev = String.format("%.2f", totalPricePrevMonth);
        pmonth.setText(formattedTotalPricePrev);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
        
         //total income 
        try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");    
    PreparedStatement pst = con.prepareStatement("SELECT SUM(price) AS total_price FROM payments");
    ResultSet rs = pst.executeQuery();
    
    if (rs.next()) {
        double totalIncome = rs.getDouble("total_price");
        String formattedTotal = String.format("%.2f", totalIncome);
        totalincome.setText(formattedTotal);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        //delete payments
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
            PreparedStatement pst = con.prepareStatement("DELETE FROM payments where paymentid = ?");
            DefaultTableModel model = (DefaultTableModel)paytable.getModel();
            pst.setString(1,payid.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this,"Record Deleted Sucessfully");
            payid.setText(null);
            appid.setText(null);
            patid.setText(null);
            service.setSelectedItem(null);
            datep.setText(null);
            price.setText(null);


        }catch(Exception e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        
         //this month income
       try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");   
    PreparedStatement pst = con.prepareStatement("SELECT COALESCE(SUM(price), 0) AS total_price FROM payments WHERE MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())");
    ResultSet rs = pst.executeQuery();
    
    if (rs.next()) {
        double totalPriceThisMonth = rs.getDouble("total_price");
        String formattedTotalPrice = String.format("%.2f", totalPriceThisMonth);
        tmonth.setText(formattedTotalPrice);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

    con.close();

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
       
       //previous month income
       try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");
     PreparedStatement pst = con.prepareStatement("SELECT SUM(price) AS total_price FROM payments WHERE MONTH(date) = MONTH(CURRENT_DATE) - 1 AND YEAR(date) = YEAR(CURRENT_DATE) - (CASE WHEN MONTH(CURRENT_DATE) = 1 THEN 1 ELSE 0 END)");
     ResultSet rs = pst.executeQuery()) {

    if (rs.next()) {
        double totalPricePrevMonth = rs.getDouble("total_price");
        String formattedTotalPricePrev = String.format("%.2f", totalPricePrevMonth);
        pmonth.setText(formattedTotalPricePrev);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
        
         //total income 
        try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ngitidtb?zeroDateTimeBehavior=convertToNull", "root", "");    
    PreparedStatement pst = con.prepareStatement("SELECT SUM(price) AS total_price FROM payments");
    ResultSet rs = pst.executeQuery();
    
    if (rs.next()) {
        double totalIncome = rs.getDouble("total_price");
        String formattedTotal = String.format("%.2f", totalIncome);
        totalincome.setText(formattedTotal);
    } else {
        JOptionPane.showMessageDialog(null, "No Payments Found for the Current Month");
    }

} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage());
}
    }//GEN-LAST:event_jButton3ActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed

    }//GEN-LAST:event_searchActionPerformed

    private void searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchKeyReleased
        //searach payment
        DefaultTableModel table=(DefaultTableModel)paytable.getModel();
        TableRowSorter<DefaultTableModel> obj =new TableRowSorter<>(table);
        paytable.setRowSorter(obj);
        obj.setRowFilter(RowFilter.regexFilter(search.getText()));
    }//GEN-LAST:event_searchKeyReleased

    private void showpatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showpatMouseClicked
        showPat s = new showPat();
        s.setVisible(true);
    }//GEN-LAST:event_showpatMouseClicked

    private void showpatMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showpatMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_showpatMousePressed

    private void showpatMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showpatMouseEntered
        showpat.setForeground(new Color(12, 72, 187));
    }//GEN-LAST:event_showpatMouseEntered

    private void showpatMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showpatMouseExited
        showpat.setForeground(new Color(0,0,0));
    }//GEN-LAST:event_showpatMouseExited

    private void showaptMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showaptMouseClicked
        showApt s = new showApt();
        s.setVisible(true);
    }//GEN-LAST:event_showaptMouseClicked

    private void showaptMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showaptMouseEntered
        showapt.setForeground(new Color(12, 72, 187));
    }//GEN-LAST:event_showaptMouseEntered

    private void showaptMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showaptMouseExited
        showapt.setForeground(new Color(0,0,0));
    }//GEN-LAST:event_showaptMouseExited

    private void showaptMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showaptMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_showaptMousePressed

    private void showserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showserMouseClicked
        showSer s = new showSer();
        s.setVisible(true);
    }//GEN-LAST:event_showserMouseClicked

    private void showserMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showserMouseEntered
        showser.setForeground(new Color(12, 72, 187));
    }//GEN-LAST:event_showserMouseEntered

    private void showserMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showserMouseExited
        showser.setForeground(new Color(0,0,0));
    }//GEN-LAST:event_showserMouseExited

    private void showserMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showserMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_showserMousePressed

    private void datepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_datepActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_datepActionPerformed

    private void priceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_priceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_priceActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField appid;
    private javax.swing.JTextField datep;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbtnupl;
    private javax.swing.JTextField patid;
    private javax.swing.JTextField payid;
    private table.Table paytable;
    private javax.swing.JLabel pmonth;
    private javax.swing.JTextField price;
    private javax.swing.JTextField search;
    private ngITi_main.Combobox service;
    private javax.swing.JLabel showapt;
    private javax.swing.JLabel showpat;
    private javax.swing.JLabel showser;
    private javax.swing.JLabel tmonth;
    private javax.swing.JLabel totalincome;
    // End of variables declaration//GEN-END:variables
}
